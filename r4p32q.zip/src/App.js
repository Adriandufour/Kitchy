import React, { useState, useRef } from "react";
import { Canvas, useLoader } from "@react-three/fiber";
import { OrbitControls, TransformControls } from "@react-three/drei";
import * as THREE from "three";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter";

// ---------- Textures ----------
function useTextures() {
  const load = (name) => useLoader(THREE.TextureLoader, `/textures/${name}`);
  return {
    cabinetWhite: load("cabinet-white.jpg"),
    cabinetOak: load("cabinet-oak.jpg"),
    quartzCalacatta: load("quartz-calacatta.jpg"),
    marbleStatuario: load("marble-statuario.jpg"),
    backsplashSubway: load("backsplash-subway.jpg"),
    backsplashMosaic: load("backsplash-mosaic.jpg"),
    floorOak: load("floor-oak.jpg"),
    floorStone: load("floor-stone.jpg"),
    metalBrushed: load("metal-brushed.jpg"),
    metalMatte: load("metal-matte.jpg"),
  };
}

// ---------- Components ----------
function FloorGrid() {
  return <gridHelper args={[50, 50, "#555", "#aaa"]} />;
}

function Wall({ data, onDoubleClick, onResize }) {
  return (
    <group>
      <mesh
        position={data.position}
        rotation={data.rotation}
        onDoubleClick={(e) => {
          e.stopPropagation();
          onDoubleClick(data);
        }}
      >
        <boxGeometry args={[data.length, data.height || 2.5, 0.1]} />
        <meshStandardMaterial map={data.texture} />
      </mesh>

      {/* Right handle */}
      <TransformControls
        position={[
          data.position[0] + data.length / 2,
          data.position[1],
          data.position[2],
        ]}
        onObjectChange={(e) =>
          onResize(
            data.id,
            Math.round((e.target.position.x - data.position[0]) * 2) / 2
          )
        }
      />

      {/* Left handle */}
      <TransformControls
        position={[
          data.position[0] - data.length / 2,
          data.position[1],
          data.position[2],
        ]}
        onObjectChange={(e) =>
          onResize(
            data.id,
            Math.round((data.position[0] - e.target.position.x) * 2) / 2
          )
        }
      />
    </group>
  );
}

function Cabinet({ data, onDoubleClick }) {
  const dims =
    data.type === "Wall"
      ? { w: 1, h: 0.9, d: 0.3 }
      : data.type === "Tall"
      ? { w: 1, h: 2.4, d: 0.6 }
      : { w: 1, h: 1, d: 0.5 };
  return (
    <mesh
      position={data.position}
      rotation={data.rotation}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onDoubleClick(data);
      }}
    >
      <boxGeometry args={[dims.w, dims.h, dims.d]} />
      <meshStandardMaterial map={data.texture} />
    </mesh>
  );
}

function Appliance({ data, onDoubleClick }) {
  const dims =
    data.type === "Fridge"
      ? { w: 0.9, h: 1.8, d: 0.7 }
      : { w: 0.9, h: 0.9, d: 0.6 };
  return (
    <mesh
      position={data.position}
      rotation={data.rotation}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onDoubleClick(data);
      }}
    >
      <boxGeometry args={[dims.w, dims.h, dims.d]} />
      <meshStandardMaterial map={data.texture} />
    </mesh>
  );
}

function Toolbar({
  room,
  setRoom,
  view,
  setView,
  lighting,
  setLighting,
  exportGLB,
}) {
  return (
    <div className="flex justify-between items-center p-2 bg-gray-200">
      <div className="flex gap-2">
        <select value={room} onChange={(e) => setRoom(e.target.value)}>
          <option>Kitchen</option>
          <option>Bath</option>
        </select>
        <select value={view} onChange={(e) => setView(e.target.value)}>
          <option>Perspective</option>
          <option>Front Elevation</option>
          <option>Top Plan</option>
        </select>
        <select value={lighting} onChange={(e) => setLighting(e.target.value)}>
          <option>Daylight</option>
          <option>Warm Interior</option>
          <option>Studio</option>
        </select>
      </div>
      <div className="flex gap-2">
        <button
          onClick={exportGLB}
          className="bg-blue-500 text-white px-2 py-1 rounded"
        >
          Export GLB
        </button>
      </div>
    </div>
  );
}

// ---------- Main ----------
export default function DesignPrototype() {
  const textures = useTextures();
  const exporter = useRef(new GLTFExporter());

  const [room, setRoom] = useState("Kitchen");
  const [view, setView] = useState("Perspective");
  const [lighting, setLighting] = useState("Daylight");
  const [selectedObject, setSelectedObject] = useState(null);

  const [samples, setSamples] = useState({
    Kitchen: {
      walls: [
        {
          id: 1,
          position: [0, 1.25, -5],
          rotation: [0, 0, 0],
          length: 10,
          texture: textures.backsplashSubway,
        },
      ],
      cabinets: [
        {
          id: 1,
          position: [0, 0.5, -4],
          rotation: [0, 0, 0],
          type: "Base",
          texture: textures.cabinetWhite,
        },
      ],
      appliances: [
        {
          id: 1,
          position: [-1, 0.5, -4],
          rotation: [0, 0, 0],
          type: "Range",
          texture: textures.metalBrushed,
        },
      ],
    },
    Bath: {
      walls: [
        {
          id: 1,
          position: [0, 1.25, -5],
          rotation: [0, 0, 0],
          length: 8,
          texture: textures.marbleStatuario,
        },
      ],
      cabinets: [],
      appliances: [],
    },
  });

  const exportGLB = () => {
    const scene = document.querySelector("canvas").__r3f.root.scene;
    exporter.current.parse(scene, (gltf) => {
      const blob = new Blob(
        [gltf instanceof ArrayBuffer ? gltf : JSON.stringify(gltf)],
        { type: "application/octet-stream" }
      );
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "design.glb";
      link.click();
    });
  };

  const handleResizeWall = (id, deltaLength) => {
    setSamples((prev) => {
      const updated = { ...prev };
      const wall = updated[room].walls.find((w) => w.id === id);
      if (wall) wall.length += deltaLength;
      return updated;
    });
  };

  return (
    <div className="w-full h-screen flex flex-col">
      <Toolbar
        room={room}
        setRoom={setRoom}
        view={view}
        setView={setView}
        lighting={lighting}
        setLighting={setLighting}
        exportGLB={exportGLB}
      />
      <Canvas
        camera={{
          position: view === "Top Plan" ? [0, 20, 0] : [5, 5, 5],
          up: [0, 1, 0],
        }}
      >
        {lighting === "Daylight" && <ambientLight intensity={0.8} />}
        {lighting === "Warm Interior" && (
          <hemisphereLight
            intensity={0.9}
            color="#ffddaa"
            groundColor="#886644"
          />
        )}
        {lighting === "Studio" && (
          <spotLight intensity={1.2} position={[10, 10, 10]} />
        )}
        <FloorGrid />
        {samples[room].walls.map((w) => (
          <Wall
            key={w.id}
            data={w}
            onDoubleClick={setSelectedObject}
            onResize={handleResizeWall}
          />
        ))}
        {samples[room].cabinets.map((c) => (
          <Cabinet key={c.id} data={c} onDoubleClick={setSelectedObject} />
        ))}
        {samples[room].appliances.map((a) => (
          <Appliance key={a.id} data={a} onDoubleClick={setSelectedObject} />
        ))}
        <OrbitControls
          enableRotate={view !== "Top Plan"}
          enablePan
          enableZoom
        />
      </Canvas>

      {selectedObject && (
        <div className="absolute top-16 right-2 bg-white shadow p-3 rounded w-64">
          <h3 className="font-bold mb-2">Properties</h3>
          {Object.keys(selectedObject).map(
            (key) =>
              typeof selectedObject[key] !== "object" && (
                <div key={key} className="mb-1">
                  <label className="block text-xs capitalize">{key}</label>
                  <input
                    type="text"
                    value={selectedObject[key]}
                    onChange={(e) =>
                      setSelectedObject({
                        ...selectedObject,
                        [key]: e.target.value,
                      })
                    }
                    className="border p-1 w-full text-sm"
                  />
                </div>
              )
          )}
        </div>
      )}
    </div>
  );
}
