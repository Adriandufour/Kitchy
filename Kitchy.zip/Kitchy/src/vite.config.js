import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Fully disable host checking for Replit previews
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',     // Allow external access
    port: 5173,          // Default dev port
    strictPort: false,   // If 5173 busy, try next
    allowedHosts: ['*'], // Accept any host
    cors: true           // Prevent CORS issues
  }
})
