import React from 'react'
import './CanvasArea.css'

export default function CanvasArea() {
  return (
    <div className="canvas-area">
      <canvas id="drafting-canvas"></canvas>
    </div>
  )
}
