import React, { useContext } from 'react'
import { WallContext } from './WallContext'
import './LeftBar.css'

export default function LeftBar() {
  const { startWallPlacement } = useContext(WallContext)

  return (
    <div className="left-bar">
      <button onClick={startWallPlacement}>New Wall</button>
    </div>
  )
}
