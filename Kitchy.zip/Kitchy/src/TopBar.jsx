import React from 'react'
import './TopBar.css'

export default function TopBar() {
  return (
    <div className="top-bar">
      🚀 Kitchy is Running on Replit!
    </div>
  )
}
