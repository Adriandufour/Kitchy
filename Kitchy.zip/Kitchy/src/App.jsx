import React from 'react'
import TopBar from './TopBar.jsx'
import LeftBar from './LeftBar.jsx'
import CanvasArea from './CanvasArea.jsx'

export default function App() {
  return (
    <div className="app-container">
      <TopBar />
      <div className="main-layout">
        <LeftBar />
        <CanvasArea />
      </div>
    </div>
  )
}
