import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import { WallProvider } from './WallContext'
import './index.css'

// Render App with WallProvider
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <WallProvider>
      <App />
    </WallProvider>
  </React.StrictMode>
)
