import React, { createContext, useState } from 'react'

export const WallContext = createContext()

export const WallProvider = ({ children }) => {
  const [walls, setWalls] = useState([])
  const [selectedWalls, setSelectedWalls] = useState([])

  const startWallPlacement = () => {
    console.log('Wall placement started...')
  }

  return (
    <WallContext.Provider value={{
      walls,
      selectedWalls,
      startWallPlacement
    }}>
      {children}
    </WallContext.Provider>
  )
}
